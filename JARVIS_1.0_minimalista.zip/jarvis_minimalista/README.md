# JARVIS 1.0 — protótipo minimalista

Esta é a primeira versão funcional do seu assistente pessoal. Ela roda no navegador e não precisa de instalação nem de chave de API.

## O que já funciona
- Interface futurista responsiva para computador e celular.
- Conversa com comandos básicos.
- Leitura das respostas em voz alta (quando suportada pelo navegador).
- Reconhecimento de voz (quando suportado e com permissão do microfone).
- Data e horário locais.
- Notas guardadas no armazenamento local do navegador.
- Abertura de pesquisas no Google.

## Limite importante
Esta versão ainda **não tem um modelo de IA conectado**. As respostas são baseadas em comandos simples e mensagens de orientação. A conexão com um modelo de linguagem será a próxima etapa. Não coloque uma chave secreta de API dentro do `app.js` ou do HTML: qualquer pessoa poderia encontrá-la.

## Como executar no computador
1. Extraia o arquivo ZIP.
2. Abra a pasta `jarvis_minimalista`.
3. Dê dois cliques em `index.html` para abrir no navegador.
4. Para testar o microfone, prefira servir a pasta por um servidor local (veja abaixo), pois alguns navegadores restringem recursos de voz em arquivos locais.

### Opção com Python (se já estiver instalado)
Abra o terminal dentro da pasta e execute:

```bash
python -m http.server 8000
```

Depois acesse `http://localhost:8000`.

## Como abrir no iPhone
Para usar no iPhone fora do computador, publique a pasta em um serviço de hospedagem estática, como GitHub Pages:
1. Crie uma conta no GitHub.
2. Crie um repositório público chamado `jarvis-pessoal`.
3. Envie os arquivos `index.html`, `style.css` e `app.js` para a raiz do repositório.
4. Em Settings → Pages, habilite a publicação a partir da branch `main` e da pasta `/ (root)`.
5. Aguarde o endereço do site aparecer na área Pages e abra-o no Safari.
6. No Safari, use Compartilhar → Adicionar à Tela de Início para criar um atalho.

A disponibilidade de reconhecimento de voz varia conforme o navegador e o aparelho. Se o microfone não funcionar no Safari, teste a digitação ou use um navegador compatível.

## Comandos para testar
- `Que horas são?`
- `Que dia é hoje?`
- `Anote comprar presente`
- `Minhas notas`
- `Apague as notas`
- `Pesquise previsão do tempo em Fortaleza`
- `Me ajude a organizar meu dia`
- `Ajuda`

## Privacidade
As notas e preferências ficam no armazenamento local do navegador. Elas não sincronizam automaticamente entre iPhone e computador. Não salve senhas, dados bancários ou informações sensíveis. Limpar os dados do navegador pode apagar as notas.

## Arquivos
- `index.html`: estrutura da interface.
- `style.css`: visual responsivo.
- `app.js`: comandos, voz e memória local.
