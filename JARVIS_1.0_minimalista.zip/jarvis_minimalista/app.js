const $ = (id) => document.getElementById(id);
const STORAGE = {notes: "jarvis_notes_v1", settings: "jarvis_settings_v1"};
let settings = JSON.parse(localStorage.getItem(STORAGE.settings) || '{"voice":true,"name":"senhor"}');
let notes = JSON.parse(localStorage.getItem(STORAGE.notes) || "[]");
let recognition = null;

function updateClock() {
  const now = new Date();
  $("clock").textContent = now.toLocaleTimeString("pt-BR");
  $("today").textContent = now.toLocaleDateString("pt-BR", {day:"2-digit", month:"long", year:"numeric"});
  $("dateLine").textContent = now.toLocaleDateString("pt-BR", {weekday:"long", day:"numeric", month:"long"});
}
setInterval(updateClock, 1000); updateClock();

function setStatus(text, mode="") {
  $("statusText").textContent = text.toUpperCase();
  $("orbCaption").textContent = text.toUpperCase();
  $("orbWrap").classList.remove("listening","speaking");
  if (mode) $("orbWrap").classList.add(mode);
}
function addMessage(text, who="assistant") {
  const row = document.createElement("div"); row.className = `message ${who}`;
  const avatar = document.createElement("div"); avatar.className = "avatar"; avatar.textContent = who === "assistant" ? "J" : "V";
  const bubble = document.createElement("div"); bubble.className = "bubble";
  const speaker = document.createElement("span"); speaker.className = "speaker"; speaker.textContent = who === "assistant" ? "JARVIS" : "VOCÊ";
  const p = document.createElement("p"); p.textContent = text;
  bubble.append(speaker,p); row.append(avatar,bubble); $("messages").append(row); $("messages").scrollTop = $("messages").scrollHeight;
}
function speak(text) {
  if (!settings.voice || !("speechSynthesis" in window)) return;
  window.speechSynthesis.cancel();
  const utterance = new SpeechSynthesisUtterance(text);
  utterance.lang = "pt-BR"; utterance.rate = 0.96; utterance.pitch = 0.88;
  utterance.onstart = () => setStatus("Falando", "speaking");
  utterance.onend = () => setStatus("Sistema pronto");
  const voices = speechSynthesis.getVoices();
  const ptVoice = voices.find(v => v.lang.toLowerCase().startsWith("pt-br")) || voices.find(v => v.lang.toLowerCase().startsWith("pt"));
  if (ptVoice) utterance.voice = ptVoice;
  speechSynthesis.speak(utterance);
}
function saveNotes() { localStorage.setItem(STORAGE.notes, JSON.stringify(notes)); renderNotes(); }
function renderNotes() {
  const list = $("memoryList"); list.replaceChildren();
  if (!notes.length) { const e=document.createElement("span"); e.className="empty-memory"; e.textContent="Nenhuma nota salva."; list.append(e); return; }
  notes.slice(-4).reverse().forEach(note => { const el=document.createElement("div"); el.className="memory-item"; el.textContent=note; list.append(el); });
}
function answerFor(raw) {
  const msg = raw.trim(); const q = msg.toLowerCase();
  const name = settings.name?.trim() || "senhor";
  if (/^(oi|olá|ola|bom dia|boa tarde|boa noite)\b/.test(q)) return `Olá, ${name}. Estou à disposição. Como posso ajudar?`;
  if (q.includes("que horas") || q === "horário" || q === "horario") return `Agora são ${new Date().toLocaleTimeString("pt-BR")}.`;
  if (q.includes("que dia") || q.includes("data de hoje")) return `Hoje é ${new Date().toLocaleDateString("pt-BR", {weekday:"long", day:"numeric", month:"long", year:"numeric"})}.`;
  if (q.startsWith("anote ") || q.startsWith("lembre ")) {
    const note = msg.replace(/^(anote|lembre)( que)?\s*/i,"").trim();
    if (!note) return "Diga o que deseja que eu anote. Exemplo: Anote comprar pão.";
    notes.push(note); saveNotes(); return `Anotado neste dispositivo: ${note}`;
  }
  if (q.includes("minhas notas") || q.includes("o que você anotou") || q.includes("o que voce anotou")) return notes.length ? "Estas são suas notas salvas:\n" + notes.map((n,i)=>`${i+1}. ${n}`).join("\n") : "Ainda não há notas salvas.";
  if (q.startsWith("apague as notas") || q.startsWith("limpe minhas notas")) { notes=[]; saveNotes(); return "Todas as notas locais foram apagadas."; }
  if (q.startsWith("pesquise ") || q.startsWith("pesquisar ") || q.startsWith("procure na internet ")) {
    const term = msg.replace(/^(pesquise|pesquisar|procure na internet)\s*/i,"").trim();
    if (term) { window.open("https://www.google.com/search?q="+encodeURIComponent(term), "_blank", "noopener"); return `Abri uma pesquisa na internet sobre: ${term}.`; }
  }
  if (q.includes("me ajude a organizar meu dia") || q.includes("organizar meu dia")) return "Vamos organizar seu dia. Primeiro, escolha as três tarefas mais importantes. Depois, reserve horários para cada uma e deixe um intervalo para imprevistos. Quais são suas prioridades de hoje?";
  if (q.includes("quem é você") || q.includes("quem e voce")) return "Sou o JARVIS, seu protótipo de assistente pessoal. Esta versão funciona localmente e já possui comandos básicos, voz e notas. Meu cérebro avançado será conectado em uma próxima etapa.";
  if (q.includes("o que você sabe fazer") || q.includes("o que voce sabe fazer") || q === "ajuda") return "Nesta versão posso informar data e horário, conversar com comandos simples, falar minhas respostas, salvar notas, listar ou apagar notas e abrir pesquisas na internet. Experimente: Anote comprar café.";
  return `Entendido, ${name}. Ainda estou na versão inicial e não tenho um modelo de IA conectado para responder livremente a qualquer assunto. Posso executar os comandos básicos: horário, data, notas e pesquisas. Na próxima etapa vamos conectar um modelo de linguagem para dar inteligência conversacional avançada.`;
}
function sendMessage(text) {
  const clean = text.trim(); if (!clean) return;
  addMessage(clean, "user"); $("messageInput").value = "";
  setStatus("Processando");
  window.setTimeout(() => { const reply = answerFor(clean); addMessage(reply); speak(reply); if (!settings.voice || !("speechSynthesis" in window)) setStatus("Sistema pronto"); }, 250);
}
$("chatForm").addEventListener("submit", e => { e.preventDefault(); sendMessage($("messageInput").value); });
document.querySelectorAll(".quick").forEach(btn => btn.addEventListener("click",()=>sendMessage(btn.dataset.command)));
$("clearButton").addEventListener("click",()=>{ $("messages").replaceChildren(); addMessage("Conversa limpa. Continuo à disposição."); });
$("viewMemory").addEventListener("click",()=>addMessage("Para salvar uma nota, escreva: Anote [sua nota]. Para consultar, diga: Minhas notas. Para apagar tudo, diga: Apague as notas. As notas ficam apenas neste navegador."));
$("settingsButton").addEventListener("click",()=>{ $("voiceToggle").checked=!!settings.voice; $("userName").value=settings.name||""; $("settingsDialog").showModal(); });
$("saveSettings").addEventListener("click",()=>{ settings={voice:$("voiceToggle").checked,name:$("userName").value.trim()||"senhor"}; localStorage.setItem(STORAGE.settings,JSON.stringify(settings)); });
$("micButton").addEventListener("click",()=>{
  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SpeechRecognition) { addMessage("Seu navegador não oferece reconhecimento de voz nesta página. Tente abrir no Google Chrome ou use a digitação."); return; }
  if (recognition) { recognition.stop(); return; }
  recognition = new SpeechRecognition(); recognition.lang="pt-BR"; recognition.interimResults=false; recognition.maxAlternatives=1;
  recognition.onstart=()=>{ $("micButton").classList.add("active"); setStatus("Ouvindo","listening"); };
  recognition.onresult=e=>{ const spoken=e.results[0][0].transcript; $("messageInput").value=spoken; sendMessage(spoken); };
  recognition.onerror=e=>{ addMessage("Não consegui reconhecer a voz ("+e.error+"). Verifique a permissão do microfone e tente novamente."); setStatus("Sistema pronto"); };
  recognition.onend=()=>{ $("micButton").classList.remove("active"); recognition=null; if (!$("orbWrap").classList.contains("speaking")) setStatus("Sistema pronto"); };
  recognition.start();
});
renderNotes();
if (!("speechSynthesis" in window)) $("voiceToggle").checked=false;
